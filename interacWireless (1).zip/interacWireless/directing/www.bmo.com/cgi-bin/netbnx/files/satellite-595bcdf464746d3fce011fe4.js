
/* JavaScript content from lib/e9f82624cf1d9ed9b3f9882ceaf5e5c5cee1c21f/scripts/satellite-595bcdf464746d3fce011fe4.js in folder common */
//console.log("Push");


s.prop13 = window.location.href;
  
s.prop18 = "";
s.prop41 = "";
s.prop42 = "";
s.prop43 = "";
s.prop11 = "";
s.eVar21 = "";
s.eVar44 = "";
s.events = "";
s.products = "";
