
/* JavaScript content from lib/e9f82624cf1d9ed9b3f9882ceaf5e5c5cee1c21f/scripts/satellite-595297f664746d0ba50032e9.js in folder common */

sitePrefix = 'APP';
var pageNameMapping = {};

//channelDemo
pageNameMapping["atm_en"]="channelDemo";
pageNameMapping["atm_fr"]="channelDemo";

//Every Day Banking
